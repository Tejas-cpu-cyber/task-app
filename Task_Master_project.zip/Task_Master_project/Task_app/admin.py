from django.contrib import admin
from Task_app.models import TaskApp

admin.site.register((TaskApp))
